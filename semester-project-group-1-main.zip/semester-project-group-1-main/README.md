# Semester-Project

## Algorithm Visualization

This program produces a graphical visualization of different algorithms.

<img width="808" alt="Screen Shot 2021-12-03 at 16 30 02" src="https://user-images.githubusercontent.com/54292420/144681414-eb469b44-b2d5-47ff-bfe3-01e41fe0f198.png">

###### This project has been developed using Java und JavaFX version 17.

